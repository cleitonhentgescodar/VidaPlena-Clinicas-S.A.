VidaPlena Clínicas S.A. - Dataset Sintético

Arquivos:
- pacientes.csv
- medicos.csv
- unidades.csv
- agendamentos.csv
- faturamento.csv
- avaliacoes.csv
- dicionario_dados.csv

Resumo:
- Pacientes: 12,000
- Médicos: 90
- Unidades: 10
- Agendamentos: 51,341
- Faturamento: 39,204
- Avaliações: 12,937

Indicadores rápidos:
- % realizado: 76.4%
- % no-show: 15.4%
- Ticket médio consulta realizada: R$ 106.69
- Nota média: 3.94
